import numpy as np
import matplotlib.pyplot as plt

# A reservori computer. The output weights are trained using ridge regression.

ridgeParameter = 0.01
predictionHorizon = 500
sizeInput = 3
sizeReservoir = 500

trainingSet = np.genfromtxt("training_set.csv", delimiter=",") # shape=(3,19900)
testSet = np.genfromtxt("test_set_4.csv", delimiter=",") # shape=(3,100)

weightsIn = np.random.normal(loc=0.0, scale= np.sqrt(0.002), size=(sizeReservoir, sizeInput)) # shape=(500,3)
weightsRes = np.random.normal(loc=0.0, scale= np.sqrt(2/sizeReservoir), size=(sizeReservoir, sizeReservoir)) # shape=(500,500)


# calc states of neurons in reservoir
X = np.zeros(shape=(trainingSet.shape[1], sizeReservoir)) # shape=(19900,500)

for i in range(trainingSet.shape[1]): # range(19900)
    nextState = np.zeros(shape=(500,1)) #initial reservoir states
    term1 = np.matmul(weightsRes,nextState) # shape = (500,1)
    term2 = np.matmul(weightsIn,trainingSet[:,i]) # shape = (500,)
    term2 = np.reshape(term2, (500,1)) # shape = (500,1)
    nextState = np.tanh(term1 + term2) # shape = (500,1)
    X[i,:] = nextState[:,0] # shape = (500,1)


# update output weights
X = X[0:19899,:] # shape = (19899, 500)
Y = trainingSet[:,1:] # shape = (3,19899)

ridgeMatrix = ridgeParameter * np.identity(sizeReservoir) #shape = (500,500)
doubleX = np.matmul(X.T,X) # shape = (500,500)
inversTerm = np.linalg.inv(doubleX + ridgeMatrix) # shape = (500,500)
nextMatrix = np.matmul(X.T,Y.T) # shape = (500,3)
weightsOut = np.matmul(inversTerm,nextMatrix) # shape = (500,3)
weightsOut = weightsOut.T # shape = (3,500)

# output testSet
testX = np.zeros(shape=(testSet.shape[1]+predictionHorizon, sizeReservoir)) # shape = (600,500)
outputX = np.zeros(shape=(sizeInput,testSet.shape[1]+predictionHorizon)) # shape = (3,600)

for i in range(testSet.shape[1]+predictionHorizon): # range(600)
    nextState = np.zeros(shape=(500,1)) #initial reservoir states
    if i < testSet.shape[1]:
        term1 = np.matmul(weightsRes,nextState) # shape = (500,1)
        term2 = np.matmul(weightsIn,testSet[:,i]) #shape = (500,)
        term2 = np.reshape(term2, (500,1)) # shape = (500,1)
        nextState = np.tanh(term1 + term2) # shape = (500,1)
        testX[i,:] = nextState[:,0]

        output = np.matmul(weightsOut,nextState) # shape = (3,1)
        outputX[:,i] = output[:,0]
        # print(testSet[:,i+1])
        # print(output)
    
    else:
        term1 = np.matmul(weightsRes,nextState) # shape = (500,1)
        term2 = np.matmul(weightsIn,output) # shape = (500,)
        term2 = np.reshape(term2, (500,1)) # shape = (500,1)
        nextState = np.tanh(term1 + term2) # shape = (500,1)
        testX[i,:] = nextState[:,0]

        output = np.matmul(weightsOut,nextState) # shape = (3,1)
        outputX[:,i] = output[:,0]



predOutput = outputX[:,100:]

tempPrediction = predOutput[1,:]
prediction = np.reshape(tempPrediction,(1,500))

np.savetxt('prediction.csv', prediction, delimiter=',')