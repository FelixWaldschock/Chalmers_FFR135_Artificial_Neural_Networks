import numpy as np
import matplotlib.pyplot as plt

sizeInput = 3
sizeReservoir = 500

trainingSet = np.genfromtxt("training_set.csv", delimiter=",") # shape=(3,19900)
testSet = np.genfromtxt("test_set_4.csv", delimiter=",") # shape=(3,100)

weightsIn = np.random.normal(loc=0.0, scale= 0.002, size=(sizeReservoir, sizeInput))
weightsRes = np.random.normal(loc=0.0, scale= np.sqrt(2/sizeReservoir), size=(sizeReservoir, sizeReservoir))


A = np.matmul(weightsIn,trainingSet[:,0])
print(np.shape(A))
print(A)

